INSERT INTO kjøttkroken.clients (firstname, lastname, email)
VALUES (
    'Bill',
    'Gates',
    'bill.gates@gmail.com'
  );